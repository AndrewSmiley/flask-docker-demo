flask-docker-demo
=================

Testing flask+docker for deployment on Amazon Web Services 
